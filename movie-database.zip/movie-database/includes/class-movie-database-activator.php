<?php
class Movie_Database_Activator {
    public static function activate() {
        flush_rewrite_rules();
    }
}
