<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

$admin = new Movie_Database_Admin();
$admin->settings_page();
?>
